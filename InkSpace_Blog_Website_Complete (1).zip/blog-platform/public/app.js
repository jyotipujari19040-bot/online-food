const blogList = document.getElementById("blogList");
const blogCount = document.getElementById("blogCount");
const authModal = document.getElementById("authModal");
const authForm = document.getElementById("authForm");
const authMessage = document.getElementById("authMessage");
const writeSection = document.getElementById("writeSection");
let authMode = "login";
let currentUser = null;

const escapeHTML = (value = "") => String(value).replace(/[&<>"']/g, c => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[c]));

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed.");
  return data;
}

function setAuthUI(user) {
  currentUser = user;
  document.getElementById("authNav").classList.toggle("hidden", !!user);
  document.getElementById("logoutNav").classList.toggle("hidden", !user);
  document.getElementById("writeNav").classList.toggle("hidden", !user);
  writeSection.classList.toggle("hidden", !user);
}

async function loadUser() {
  try {
    const data = await api("/api/auth/me");
    setAuthUI(data.user);
  } catch { setAuthUI(null); }
}

async function loadBlogs() {
  try {
    const { blogs } = await api("/api/blogs");
    blogCount.textContent = `${blogs.length} ${blogs.length === 1 ? "story" : "stories"}`;
    if (!blogs.length) {
      blogList.innerHTML = '<p class="muted">No stories yet. Log in and publish the first one.</p>';
      return;
    }
    blogList.innerHTML = blogs.map(blog => `
      <article class="blog-card">
        <span class="tag">${escapeHTML(blog.category || "General")}</span>
        <h3>${escapeHTML(blog.title)}</h3>
        <p>${escapeHTML(blog.excerpt || "Open this story to read the full article.")}</p>
        <div class="card-meta"><span>By ${escapeHTML(blog.author?.name || "Unknown")}</span>
          <a class="read-link" href="/?blog=${encodeURIComponent(blog._id)}">Read story →</a></div>
      </article>`).join("");
  } catch (error) {
    blogList.innerHTML = `<p class="muted">${escapeHTML(error.message)}</p>`;
  }
}

async function showBlogIfRequested() {
  const id = new URLSearchParams(location.search).get("blog");
  if (!id) return;
  try {
    const { blog } = await api(`/api/blogs/${encodeURIComponent(id)}`);
    const detail = document.createElement("section");
    detail.className = "section";
    detail.innerHTML = `
      <a class="read-link" href="/">← Back to all stories</a>
      <p class="eyebrow" style="margin-top:28px">${escapeHTML(blog.category || "General")}</p>
      <h1 style="font:700 clamp(36px,5vw,58px) 'Playfair Display',serif;max-width:850px">${escapeHTML(blog.title)}</h1>
      <p class="muted">By ${escapeHTML(blog.author?.name || "Unknown")} · ${new Date(blog.createdAt).toLocaleDateString()}</p>
      <p style="max-width:850px;white-space:pre-wrap;line-height:1.9;font-size:16px;margin-top:35px">${escapeHTML(blog.content)}</p>`;
    document.querySelector("main").prepend(detail);
    document.getElementById("blogs").classList.add("hidden");
    document.getElementById("home").classList.add("hidden");
    writeSection.classList.add("hidden");
  } catch (error) {
    alert(error.message);
  }
}

function chooseAuthMode(mode) {
  authMode = mode;
  const registering = mode === "register";
  document.getElementById("authTitle").textContent = registering ? "Create your account" : "Welcome back";
  document.getElementById("nameLabel").classList.toggle("hidden", !registering);
  authForm.elements.name.required = registering;
  authForm.elements.password.autocomplete = registering ? "new-password" : "current-password";
  document.getElementById("authSubmit").textContent = registering ? "Create account" : "Login";
  document.getElementById("loginTab").classList.toggle("active", !registering);
  document.getElementById("registerTab").classList.toggle("active", registering);
  authMessage.textContent = "";
}

document.getElementById("authNav").addEventListener("click", () => {
  authModal.classList.remove("hidden");
  chooseAuthMode("login");
});
document.getElementById("closeModal").addEventListener("click", () => authModal.classList.add("hidden"));
document.getElementById("loginTab").addEventListener("click", () => chooseAuthMode("login"));
document.getElementById("registerTab").addEventListener("click", () => chooseAuthMode("register"));
document.getElementById("writeNav").addEventListener("click", () => writeSection.scrollIntoView({ behavior: "smooth" }));

authForm.addEventListener("submit", async event => {
  event.preventDefault();
  authMessage.textContent = "Please wait...";
  const form = new FormData(authForm);
  const body = Object.fromEntries(form.entries());
  try {
    const data = await api(`/api/auth/${authMode}`, { method: "POST", body: JSON.stringify(body) });
    setAuthUI(data.user);
    authModal.classList.add("hidden");
    authForm.reset();
  } catch (error) { authMessage.textContent = error.message; }
});

document.getElementById("logoutNav").addEventListener("click", async () => {
  try { await api("/api/auth/logout", { method: "POST" }); }
  finally { setAuthUI(null); }
});

document.getElementById("blogForm").addEventListener("submit", async event => {
  event.preventDefault();
  const message = document.getElementById("writeMessage");
  message.textContent = "Publishing...";
  const body = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    await api("/api/blogs", { method: "POST", body: JSON.stringify(body) });
    event.currentTarget.reset();
    message.textContent = "Your blog has been published!";
    await loadBlogs();
    document.getElementById("blogs").scrollIntoView({ behavior: "smooth" });
  } catch (error) { message.textContent = error.message; }
});

(async function init() {
  await loadUser();
  await loadBlogs();
  await showBlogIfRequested();
})();
