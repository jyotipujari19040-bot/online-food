# InkSpace — Full-stack Blog Website

A ready-to-run blog platform built with **Node.js, Express, MongoDB, Mongoose, HTML, CSS and JavaScript**.

## Features

- User registration and login
- Password hashing with bcrypt
- JWT authentication stored in an HttpOnly cookie
- Create and publish blog posts (logged-in users)
- Retrieve and display all blogs from MongoDB
- Open an individual blog detail page
- Author name, category, excerpt and publishing date
- Responsive frontend
- Basic security headers and API rate limiting

## 1. Requirements

Install:
- Node.js 18 or newer
- npm
- A MongoDB database (MongoDB Atlas free cluster or local MongoDB)

## 2. Set up MongoDB Atlas

1. Create a free cluster at https://www.mongodb.com/atlas.
2. Create a database user and password.
3. In Network Access, allow your development IP address.
4. Select **Connect → Drivers** and copy the connection string.
5. Replace the username, password and database name in the connection string.

Do not share your database password or commit it to GitHub.

## 3. Run the website locally

Open a terminal in this project folder and run:

```bash
npm install
```

Copy `.env.example` to `.env` and edit `.env`:

```env
PORT=5000
MONGODB_URI=your_mongodb_atlas_connection_string
JWT_SECRET=use_a_long_random_secret_value
NODE_ENV=development
```

Then start the app:

```bash
npm run dev
```

Open http://localhost:5000

For normal start (without auto-reload):

```bash
npm start
```

## 4. API endpoints

| Method | Endpoint | Purpose | Access |
|---|---|---|---|
| POST | `/api/auth/register` | Register a user | Public |
| POST | `/api/auth/login` | Log in | Public |
| GET | `/api/auth/me` | Get current user | Authenticated |
| POST | `/api/auth/logout` | Log out | Public |
| GET | `/api/blogs` | Get all blog posts | Public |
| GET | `/api/blogs/:id` | Get one blog post | Public |
| POST | `/api/blogs` | Create a blog post | Authenticated |
| GET | `/api/health` | Health check | Public |

## 5. Publish to GitHub

1. Create a new empty repository on https://github.com/new.
2. Extract this ZIP file.
3. Open a terminal inside the `blog-platform` folder.
4. Run:

```bash
git init
git add .
git commit -m "Initial full-stack blog website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the remote URL with your own repository URL. Confirm `.env` is not included before pushing.

## 6. LinkedIn project post

After the GitHub repository is public, you can share this:

> Excited to share my Full-Stack Blog Website project!
>
> I built a blog platform using Node.js, Express.js, MongoDB, Mongoose, HTML, CSS and JavaScript.
>
> Key features:
> - User registration and login
> - Secure password hashing
> - JWT-based authentication
> - Create and publish blog posts
> - View all blogs and individual blog details
> - MongoDB database integration
>
> This project helped me practise backend development, REST API creation, database integration and frontend-backend connectivity.
>
> GitHub: [Add your repository link]
>
> #WebDevelopment #NodeJS #ExpressJS #MongoDB #FullStackDevelopment #LearningByDoing

## Security notes

- Never commit `.env` or real database credentials.
- Use a long, random `JWT_SECRET`.
- For production, use HTTPS and set `NODE_ENV=production`.
- Add stricter validation, CSRF protection and deployment-specific configuration before exposing this app publicly.
