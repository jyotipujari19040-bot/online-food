const mongoose = require("mongoose");

const blogSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 140 },
  excerpt: { type: String, trim: true, maxlength: 240, default: "" },
  content: { type: String, required: true, trim: true, maxlength: 20000 },
  category: { type: String, trim: true, maxlength: 40, default: "General" },
  author: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
}, { timestamps: true });

module.exports = mongoose.model("Blog", blogSchema);
