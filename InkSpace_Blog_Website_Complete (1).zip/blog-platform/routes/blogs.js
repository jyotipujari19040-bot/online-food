const router = require("express").Router();
const Blog = require("../models/Blog");
const requireAuth = require("../middleware/requireAuth");

// Public: retrieve all blog posts
router.get("/", async (_req, res, next) => {
  try {
    const blogs = await Blog.find()
      .populate("author", "name")
      .sort({ createdAt: -1 })
      .select("title excerpt category author createdAt");
    res.json({ blogs });
  } catch (error) { next(error); }
});

// Public: retrieve one blog post by its MongoDB ID
router.get("/:id", async (req, res, next) => {
  try {
    const blog = await Blog.findById(req.params.id).populate("author", "name");
    if (!blog) return res.status(404).json({ message: "Blog post not found." });
    res.json({ blog });
  } catch (error) {
    if (error.name === "CastError") return res.status(404).json({ message: "Blog post not found." });
    next(error);
  }
});

// Authenticated: create a blog post
router.post("/", requireAuth, async (req, res, next) => {
  try {
    const { title, excerpt, content, category } = req.body;
    if (!title || !content) return res.status(400).json({ message: "Title and content are required." });
    const blog = await Blog.create({
      title: String(title).trim(),
      excerpt: String(excerpt || "").trim(),
      content: String(content).trim(),
      category: String(category || "General").trim(),
      author: req.user.id
    });
    await blog.populate("author", "name");
    res.status(201).json({ blog });
  } catch (error) { next(error); }
});

module.exports = router;
