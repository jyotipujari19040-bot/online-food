const jwt = require("jsonwebtoken");

module.exports = function requireAuth(req, res, next) {
  const token = req.cookies.blog_token;
  if (!token) return res.status(401).json({ message: "Please log in to continue." });

  try {
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch (_error) {
    res.clearCookie("blog_token");
    return res.status(401).json({ message: "Your session expired. Please log in again." });
  }
};
